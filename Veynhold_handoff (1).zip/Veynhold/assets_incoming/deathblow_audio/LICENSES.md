# Licences: deathblow audio

All 31 `.ogg` layers, the preview WAVs and the spectrograms were **synthesised from scratch** by `_tools/synth.py` and `_tools/render.py`, written for this project. They use numpy noise, oscillators, state-variable filters and Karplus-Strong plucks, encoded with ffmpeg/libopus. No recorded samples or third-party sound files went into them: no Kenney, OpenGameArt, Sonniss or freesound material.

| file(s) | source | licence |
|---|---|---|
| bell_low, bell_swell, body_fall, body_fall_armour, bone_grind, cloth_grab, crunch, crunch_heavy, draw_ring, draw_ring_low, drive_shoulder, drone_cold, drone_fall, drone_king, edge_tick_soft, flesh_thud, ink_puff, koto_a3, koto_arp, koto_d4, koto_harm, last_breath, ring_out, ring_out_low, spray, sub_heavy, sub_hit, wet_pierce, wet_pull, whoosh_arc, whoosh_thrust (.ogg) | original synthesis, `_tools/synth.py` (this folder) | CC0 1.0, https://creativecommons.org/publicdomain/zero/1.0/ |
| preview/*.wav, preview/*_spectrogram.png | rendered from the above by `_tools/render.py` | CC0 1.0 |

Tools used at build time only (not shipped): numpy (BSD-3), FFmpeg with libopus (LGPL / BSD). Only the encoded audio is distributed, which is fine for embedding in a free game.
