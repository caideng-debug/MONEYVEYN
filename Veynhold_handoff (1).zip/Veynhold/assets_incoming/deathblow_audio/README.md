# VEYNHOLD deathblow audio (incoming, not integrated)

The audio for 6 deathblow variants, built from 31 layers (Opus in an OGG file, mono, 24 kHz). **Total 145,968 bytes**, under the 350 KB budget; about 195 KB once base64-embedded. Every layer is synthesised in `_tools/synth.py` (numpy only, seeded, so it gives the same output every run). No third-party samples are used, so the licence is simple (see LICENSES.md). No MP3s: the game makes all its sound with Web Audio and loads no audio files, and Chrome on ChromeOS decodes Opus with `decodeAudioData`.

Nothing in `src/` or `/workspace/vh_wt` was touched. Nothing is committed.

## Contents
| path | what |
|---|---|
| `*.ogg` (31) | the layers: libopus VBR, 28 kbps (20 kbps for the drones, `bell_low` and the subs); each peaks at −1 dBFS before its cue gain |
| `cues.json` | one entry per variant: its layers (`file`, `t`, `gainDb`, optional `rate`, `lp`, `send`), its `schedule`, its music `duck` envelope |
| `preview/<variant>.wav` | the full mix on the wall-clock timeline, rendered from the **encoded** files. It includes the 0.10 s Impact hit-stop, an approximation of the game's `exec` reverb send, and a stand-in music and ambience bed with the duck applied, so the duck can be heard |
| `preview/<variant>_spectrogram.png` | log-frequency spectrogram, 20 Hz–12 kHz |
| `preview/levels.json` | peak, per-beat RMS and auto-trim per variant, plus the file sizes |
| `_tools/synth.py`, `_tools/render.py` | regenerate everything: `python3 _tools/synth.py && python3 _tools/render.py`. Needs numpy and ffmpeg with libopus. `_tools/wav/` holds the 16-bit masters (not shipped) |

## Variants → existing tracks
| id | name | anim track (game.js TRACKS) | schedule |
|---|---|---|---|
| `heart` | Heart Pierce | exec_duelist / vic_duelist (default `"heart"`) | normal |
| `turning` | Turning Cut | exec_brother / vic_brother (spinThrough) | normal |
| `crown` | Crown Splitter / shoulder drive | exec_warden / vic_warden | normal |
| `stealth` | back-stab / throat cut | unseen deathblow (`world_combat.js` `sfx.muffled()`) | normal |
| `king1` | King Phase I | exec_king1 | normal (judgement call: it is not the final blow) |
| `kingsfall` | Kingsfall | exec_kingF | boss (Settle 0.80, Extract 1.45, Clear 1.65, Unlock 1.90, end 2.75) |

## Layer map (times on the deathblow clock from Commit)
- **Commit 0.00**: steel edge ring (`draw_ring`, or `draw_ring_low` for the heavy and king variants). A rising scrape, then an edge tick at 0.165 s, then inharmonic partials ringing out. Stealth uses `cloth_grab` + `edge_tick_soft` instead.
- **Drive 0.17–0.28**: `whoosh_thrust`, `whoosh_arc` (the spins and the overhead), `drive_shoulder` (foot plant, lamellar rattle, weight shift).
- **Impact 0.32**: `wet_pierce` (transient + wet wobble + bubbles), `flesh_thud`, `crunch` / `crunch_heavy` (bone), `sub_hit` / `sub_heavy` (54→27 Hz / 46→22 Hz).
- **Near-silence**: the music and ambience duck to −40…−48 dB for 0.18–0.25 s of wall time, counting the hit-stop. The world was already low-passed to about 500 Hz from Commit (Sekiro's mix snapshot).
- **Settle 0.55 (boss 0.80)**: `bone_grind` (heavy variants) or `last_breath` (heart, stealth, Kingsfall).
- **Extract 0.95 (boss 1.45)**: `wet_pull` (1.4 kHz→500 Hz suction + slurp), then the `ring_out` of the blade leaving at about Extract +0.11, then `spray` at Blade-clear.
- **Fall**: `body_fall` (knees, then torso) or `body_fall_armour` (adds plate clanks), about 0.3 s after Blade-clear. **Better: trigger it on the Col corpse ground-contact if that event exists.**
- **Payoff → Unlock** (all in D, miyako-bushi D E♭ G A B♭):
  - Normal variants: `drone_cold` swells from 0.60 to peak at Unlock, then a `koto_d4` pluck lands on Unlock 1.40. Turning Cut adds `koto_a3` just before it. Crown adds a reversed `bell_swell` whose strike lands on Unlock.
  - Stealth: no drone, only a soft high `koto_harm`, plus the `ink_puff` at 1.10.
  - King Phase I: `drone_king` holds a D/E♭ rub that never resolves, and the bell is pitched down a semitone. It is meant to hand off into the existing `phaseSting`.
  - **Kingsfall**: `drone_fall` builds from 0.80, the `bell_swell` strike lands at 1.90 together with the `bell_low` D3 temple bell and a sub, then the `koto_arp` rises D-E♭-G-A-D from 2.10. About 6 s of tail.

## Integration note (for whoever owns AudioSys in src/game.js)
The game's audio is all procedural (`AudioSys.sw`), and every asset is base64-embedded by `build.py`. Suggested wiring, all presentation-side:

1. **Embed.** In build.py, read `assets_incoming/deathblow_audio/*.ogg` and `cues.json`, then replace a `/*DB_AUDIO*/{}` placeholder with `{cues:…, files:{name: base64}}`. The same pattern is already used for `/*F_ASSETS*/`.
2. **Decode lazily** after `audio.ensure()`, so it runs after the user gesture. Decode once and cache the AudioBuffers. All decoded together they come to about 40 s of mono audio, roughly 7.8 MB as float32 at 48 kHz. Fine on a Chromebook, but don't decode per kill.
   ```js
   DB.load = async () => { const c = audio.ctx; DB.buf = {}; for (const [n, b64] of Object.entries(DB_AUDIO.files)) {
     const u8 = Uint8Array.from(atob(b64), ch => ch.charCodeAt(0)); DB.buf[n] = await c.decodeAudioData(u8.buffer); } };
   ```
3. **Fire layers on the deathblow clock, not on wall timers.** The clock pauses for the 6-tick Impact hit-stop (0.10 s), so a layer with `t > impact` must start 0.10 s later in wall time. The robust way: on `deathblowStart`, pick the variant (same lookup as §7.4). Then each presentation frame, start every layer whose `t` the clock has just crossed, using `when = ctx.currentTime` and `offset = clock − t`. Layers with `t ≤ clock` at start fire at once.
   ```js
   function fire(L) { const c = audio.ctx, s = c.createBufferSource(); s.buffer = DB.buf[L.file.replace('.ogg','')]; s.playbackRate.value = L.rate || 1;
     let n = s; if (L.lp) { const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = L.lp; f.Q.value = 0; n.connect(f); n = f; }
     const g = c.createGain(); g.gain.value = Math.pow(10, L.gainDb / 20); n.connect(g); g.connect(audio.sfxBus());
     if (L.send !== undefined) { const snd = audio.sendOf('exec'); if (snd) { const sg = c.createGain(); sg.gain.value = Math.pow(10, L.send / 20); g.connect(sg); sg.connect(snd); } }
     s.start(); }
   ```
4. **Duck.** `duck` is a list of `[t, gainDb, lowpassHz]` on the same clock; apply the hit-stop shift the same way. Interpolate linearly in dB and logarithmically in Hz, using `setValueAtTime` / `linearRampToValueAtTime` on a gain and a BiquadFilter lowpass. It must apply to the music bus **and** the ambience. Today `ambient()` connects straight to `master`, so a small duck node is needed on both paths (`bedG→musBus`, the stingers and `ambient→master`). Points after the presentation end release to 0 dB / 20 kHz over 2 s (3 s for Kingsfall).
5. **Remove the old one-shots for these variants, or they double up:** `audio.play('deathblow')` + `audio.play('execSting')` in `Game.handleEvents` `case 'deathblow'`, the `dbEntry` / `impale` sub in `world_boss.js` (H1 owns that file), and `sfx.muffled()` for unseen kills. `HUD.flash` stays.
6. **Low quality:** keep everything. The cost is a handful of BufferSources at once, about 14–18 per variant. `exec` is already on Low; optionally skip the `send` connections there.

## Levels and checks (preview/levels.json)
- An automatic trim kept the summed SFX peak at or below −3 dBFS. The trim is already baked into `cues.json` `gainDb` (−2.0 to −5.0 dB; Stealth is untrimmed at −5.0 dBFS peak). The loudest point is always the Impact (0.32–0.34 s), at RMS −12…−16 dBFS over the Impact, against −24 for the extract and −19…−27 for the payoff. Previews peak at −2.8 to −5.0 dBFS. **No clipping.**
- Spectrograms were checked for every variant. The only dense low-mid area was in Kingsfall: the first pass had drone harmonics and a bell sub-partial piling up at 80–300 Hz. The drone's 2nd and 3rd harmonics and the bell's 0.5× partial were cut, and the drone was dropped 2 dB. The remaining bright line at about 147 Hz from 2–4.7 s is the D3 bell fundamental, which is intended. In Stealth everything physical sits under about 2.5 kHz. Only the koto harmonic and the edge tick sit above that, both quiet.
- Not verified: listening on real Chromebook speakers (small speakers will lose the 22–54 Hz subs; the thud's 105→65 Hz body and the crunch carry the impact there). Also not verified: in-game timing against the real clock. Tune `gainDb` from `cues.json` once it is wired in.
