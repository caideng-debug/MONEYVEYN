/* Reference decoder / sampler for veynhold-deathblow-clip/1 (presentation only; NOT wired into src/).
   Usage:  const C = DBClip.decode(json);  const out = new Float32Array(15 * 4);
           const r = DBClip.sample(C, 'att', dbT, out);   // dbT = core deathblow clock (s), paused during core hit-stop
           // out = 15 rig-local quaternions in C.joints order (same rig and joint order as src/anim.js / anim_data.json),
           // r = { hy, x, z, yaw }: hips offset (hips.position.y = 0.95 + hy) and root in VICTIM space (victim at origin, facing +Z).
   The wrist convention is anim_data.json W0.u2 (C.W0): set the pose-rig wrist to W0 while the clip drives the arm.
   World placement: worldPos = victimPos + rotY(victimYaw) * (x, 0, z) * 1; worldYaw = victimYaw + yaw. The victim track's own root
   is relative to its start pose (x = z = 0 at t = 0). Victim scale C.victimScale is already baked into its root track spacing. */
(function (G) {
  'use strict';
  function b64(s) { const bin = atob(s), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u.buffer; }
  function decode(d) {
    const n = d.n, J = d.joints.length, t = new Uint16Array(b64(d.t)), T = new Float32Array(n);
    for (let i = 0; i < n; i++) T[i] = t[i] / 1000;
    const actors = {};
    for (const k in d.actors) {
      const a = d.actors[k], raw = new Int16Array(b64(a.q)), hy = new Int16Array(b64(a.hy)), rt = new Int16Array(b64(a.root));
      const q = new Float32Array(n * J * 4), h = new Float32Array(n), r = new Float32Array(n * 3);
      for (let i = 0; i < n * J; i++) { const x = raw[i * 3] / 32767, y = raw[i * 3 + 1] / 32767, z = raw[i * 3 + 2] / 32767;
        q[i * 4] = x; q[i * 4 + 1] = y; q[i * 4 + 2] = z; q[i * 4 + 3] = Math.sqrt(Math.max(0, 1 - x * x - y * y - z * z)); }
      for (let i = 0; i < n; i++) { h[i] = hy[i] / 10000; r[i * 3] = rt[i * 3] / 1000; r[i * 3 + 1] = rt[i * 3 + 1] / 1000; r[i * 3 + 2] = rt[i * 3 + 2] / 10000; }
      actors[k] = { q, h, r, scale: a.scale };
    }
    return Object.assign({}, d, { T, J, actors });
  }
  // keys are non-uniform (20 fps grid + a key exactly on every core tick), so find the segment by binary search
  function seg(T, t) { let lo = 0, hi = T.length - 1; if (t <= T[0]) return [0, 0, 0]; if (t >= T[hi]) return [hi, hi, 0];
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (T[m] <= t) lo = m; else hi = m; } return [lo, hi, (t - T[lo]) / Math.max(1e-6, T[hi] - T[lo])]; }
  function sample(C, who, t, out) {
    const A = C.actors[who], J = C.J, [i0, i1, u] = seg(C.T, t), q = A.q, a = i0 * J * 4, b = i1 * J * 4;
    for (let j = 0; j < J; j++) { const o = j * 4; let x1 = q[b + o], y1 = q[b + o + 1], z1 = q[b + o + 2], w1 = q[b + o + 3];
      const x0 = q[a + o], y0 = q[a + o + 1], z0 = q[a + o + 2], w0 = q[a + o + 3]; if (x0 * x1 + y0 * y1 + z0 * z1 + w0 * w1 < 0) { x1 = -x1; y1 = -y1; z1 = -z1; w1 = -w1; }
      const x = x0 + (x1 - x0) * u, y = y0 + (y1 - y0) * u, z = z0 + (z1 - z0) * u, w = w0 + (w1 - w0) * u, l = Math.hypot(x, y, z, w) || 1;
      out[o] = x / l; out[o + 1] = y / l; out[o + 2] = z / l; out[o + 3] = w / l; }
    const r = A.r, lerp = (k) => r[i0 * 3 + k] + (r[i1 * 3 + k] - r[i0 * 3 + k]) * u;
    let dy = r[i1 * 3 + 2] - r[i0 * 3 + 2]; if (dy > Math.PI) dy -= 2 * Math.PI; if (dy < -Math.PI) dy += 2 * Math.PI;
    return { hy: A.h[i0] + (A.h[i1] - A.h[i0]) * u, x: lerp(0), z: lerp(1), yaw: r[i0 * 3 + 2] + dy * u };
  }
  G.DBClip = { decode, sample };
})(typeof window !== 'undefined' ? window : globalThis);
