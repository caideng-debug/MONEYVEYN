# Licences: assets_incoming/deathblow_clips

Every animation source here is **CC0 1.0 Universal** (public domain dedication, https://creativecommons.org/publicdomain/zero/1.0/). No attribution is required. Courtesy credit: "Animations based on the Universal Animation Library 1 & 2 by Quaternius (CC0)".

| Source | Where it was obtained | Licence evidence |
|---|---|---|
| Quaternius Universal Animation Library (Standard) | https://quaternius.itch.io/universal-animation-library, mirrored at https://opengameart.org/content/universal-animation-library (already in the workspace as `work/ual/ual1.zip`) | `License.txt` in the pack: "CC0 1.0 Universal". Copy at `assets_incoming/round2/ual_combat_extra/License_UAL1.txt` |
| Quaternius Universal Animation Library 2 (Standard) | https://quaternius.itch.io/universal-animation-library-2, mirrored at https://opengameart.org/content/universal-animation-library-2 (`work/ual/ual2.zip`) | `License.txt` in the pack: "CC0 1.0 Universal". Copy at `assets_incoming/round2/ual_combat_extra/License_UAL2.txt` |
| Quaternius UAL Source/Pro single clips: Death02, Hit_Stomach, Kick, Crouch_Idle_Loop | Drawcall Market re-host: https://market.drawcall.ai/asset/death02 , /asset/hit-stomach , /asset/kick-alternate-2 , /asset/crouch-idle-loop (zips from market.drawcallcontent.com, fetched 2026-11-10) | Each asset page and README says "Quaternius Universal Animation Library … CC0 humanoid animation", source https://quaternius.com/packs/universalanimationlibrary.html. Quaternius publishes the paid Source editions under CC0 too. **Note:** this is a third-party re-host. If you want first-party provenance, the same clips are in the UAL Source edition (paid) on quaternius.com. |

The authored poses, the IK-solved strike poses and the preview images are original work made for VEYNHOLD in this workspace.

Rejected or not used: Mixamo (login, and its licence forbids redistributing the animation files); opengameasset.net "One Handed Sword Attacks and Finishers" (a re-host of a commercial pack, not CC0); OGA "Humanoid SoulsLike Animations" (CC0, but `.blend` only); Sketchfab (login).

When these are integrated, add a row to `docs/LICENSES.md`: "Deathblow animation data: derived from Quaternius UAL1/UAL2 (Standard + Source clips), CC0 1.0".
