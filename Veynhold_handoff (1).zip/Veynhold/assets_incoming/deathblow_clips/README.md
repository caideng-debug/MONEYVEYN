# Deathblow clips (VEYNHOLD): keyframe data for `docs/deathblow_direction.md`

Presentation-only data. **Nothing in `src/` uses this yet.** The format, conventions and integration sketch are in `docs/deathblow_direction.md` §0 and §11. `sample_clip.js` is a reference decoder and sampler.

- **12 files, 171.6 KB total** (budget 400 KB). The quaternions are already int16 + base64 inside the JSON, so the embedded size equals the file size.
- Rig: the game's 15-joint pose rig (`src/anim.js`, the same joints as `anim_data.json`). The pose rig drives the Quaternius UE-mannequin skins through `models.js QMAP`, so this is the game's Quaternius skeleton at the level the game animates it. Wrist convention: `W0.u2`.
- Keys: a 20 fps grid **plus a key exactly on every core tick** (Commit, Drive, Impact, Settle, Extract, Blade-clear, Unlock, presentation end) and on every authored key. Times are uint16 ms in `t`.
- Two actors per deathblow: `att` (Wren) and `vic`. Roots are in victim space. The break clips have only `vic` and loop [1.0, 2.5] s.

| File | Clock | Keys | Bytes | Vital | Blade pin at Impact (lateral m / out the far side m) |
|---|---|---|---|---|---|
| `break_heavy_kneel.json` | loop | 51 | 7618 | – | – |
| `break_heavy_stand.json` | loop | 51 | 7523 | – | – |
| `break_king_kneel.json` | loop | 51 | 7604 | – | – |
| `break_std.json` | loop | 51 | 7601 | – | – |
| `crown_splitter.json` | boss | 63 | 19465 | crown | 0.004 / 0.44 |
| `heart_pierce.json` | normal | 57 | 18486 | heart | 0.000 / 0.62 |
| `king_phase1.json` | boss | 62 | 19698 | heart | 0.005 / 0.60 |
| `kingsfall.json` | boss | 65 | 20205 | heartTop | 0.004 / 0.64 |
| `shoulder_drive.json` | normal | 57 | 17570 | clavL | 0.001 / 0.84 |
| `stealth_backstab.json` | normal | 52 | 16304 | back | 0.001 / 0.76 |
| `stealth_throat.json` | normal | 52 | 16324 | throat | 0.008 / 0.80 |
| `turning_cut.json` | normal | 56 | 17366 | throat | 0.003 / 0.54 |

## How the clips were made (pipeline: `/workspace/work/db/`, scratch, not shipped)
1. **Download.**
   - UAL1 and UAL2 Standard were already in the workspace (`work/ual/ual1.zip`, `ual2.zip`, from the Quaternius itch / OpenGameArt pages).
   - 32 single-clip UAL *Source* GLBs were fetched with curl from Drawcall Market (`work/db/dc/`, about 4 MB, scratch). 4 of them are used.
2. **Extract.** glTF JSON + binary was parsed directly in Python (`work/ual/glb.py`, `fk.py`). Node + three was not needed for extraction.
3. **Retarget** (`rt.py`). This is the same method as `work/ual/retarget.py`: for every bone, the model-space delta from the library's own T-pose is applied to the rig T-pose. Details:
   - The bone maps are the UE names for UAL2 and the Rigify DEF names for UAL1. For the normalized Source skeleton they are hips / upperChest / head / {left,right}{Upper,Lower}Arm, Hand / {Upper,Lower}Leg, Foot.
   - The Source GLBs have no `A_TPose`; their rest pose is a T-pose (verified: hands at shoulder height, ±0.74 m), so the rest pose is used.
   - The wrist is re-expressed in the `W0.u2` grip frame. The correction was identity for all three libraries, because they share Quaternius' finger layout.
4. **Retime** (`build.py`). Each track is a list of keys on the core deathblow clock. A key is either a clip frame (`Clip@seconds`) or an authored pose, plus additive Euler offsets and an ease into the key.
   - Between two keys on the same clip, the clip itself plays (time-remapped through the ease).
   - Otherwise the two key poses slerp.
   - Hips height is re-grounded every frame on the rig's proportions (feet, knees, hips, chest, head and hands as contact points).
5. **Blade pin.** Keys with a blade line (vital point, direction, hand distance) solve Wren's right arm (shoulder 3 dof, elbow, wrist 3 dof) by Nelder-Mead IK. Every exported frame between pinned keys is then re-solved, so the blade stays in the wound. Off-hand reaches (shoulder, mouth, brow, wrist grips) use the same solver.
6. **Quantise.** int16 xyz with w ≥ 0, hips 0.1 mm, root mm / 1e-4 rad.

## Sources and the frames used

Frame numbers are at the clip's native 30 fps (`seconds × 30`).

| Clip | Library / file | URL | Licence | Frames used (s → f30) | Used in |
|---|---|---|---|---|---|
| `Crouch_Fwd_Loop` | Quaternius Universal Animation Library (Standard), file `Godot/AnimationLibrary_Godot_Standard.glb` | https://quaternius.itch.io/universal-animation-library · https://opengameart.org/content/universal-animation-library | CC0 1.0 (License.txt in the pack; copy at `assets_incoming/round2/ual_combat_extra/License_UAL1.txt`) | 0.00→f0, 0.55→f16 | stealth_backstab, stealth_throat |
| `Crouch_Idle_Loop` | Quaternius Universal Animation Library 1 **Source/Pro** clip, single-clip GLB `quaternius-ual1-crouch-idle-loop.glb` (VRM-style normalized humanoid skeleton, re-hosted by Drawcall Market) | https://market.drawcall.ai/asset/crouch-idle-loop (zip: https://market.drawcallcontent.com/zips/…) · origin https://quaternius.com/packs/universalanimationlibrary.html | CC0 1.0, as stated on the Drawcall asset page ("Quaternius Universal Animation Library … Source CC0"); Quaternius releases the Source editions under CC0 too | 0.00→f0 | stealth_backstab, stealth_throat |
| `Death01` | Quaternius Universal Animation Library (Standard), file `Godot/AnimationLibrary_Godot_Standard.glb` | https://quaternius.itch.io/universal-animation-library · https://opengameart.org/content/universal-animation-library | CC0 1.0 (License.txt in the pack; copy at `assets_incoming/round2/ual_combat_extra/License_UAL1.txt`) | 0.25→f8, 0.90→f27, 1.15→f34, 1.35→f40, 2.40→f72 | crown_splitter, shoulder_drive |
| `Death02` | Quaternius Universal Animation Library 1 **Source/Pro** clip, single-clip GLB `quaternius-ual1-death02.glb` (VRM-style normalized humanoid skeleton, re-hosted by Drawcall Market) | https://market.drawcall.ai/asset/death02 (zip: https://market.drawcallcontent.com/zips/…) · origin https://quaternius.com/packs/universalanimationlibrary.html | CC0 1.0, as stated on the Drawcall asset page ("Quaternius Universal Animation Library … Source CC0"); Quaternius releases the Source editions under CC0 too | 0.30→f9, 0.35→f10, 0.60→f18, 0.85→f26, 0.90→f27, 0.95→f28, 1.00→f30, 1.05→f32, 1.10→f33, 1.55→f46, 1.90→f57, 2.00→f60, 2.40→f72 | break_king_kneel, heart_pierce, kingsfall, stealth_backstab, stealth_throat, turning_cut |
| `Fixing_Kneeling` | Quaternius Universal Animation Library (Standard), file `Godot/AnimationLibrary_Godot_Standard.glb` | https://quaternius.itch.io/universal-animation-library · https://opengameart.org/content/universal-animation-library | CC0 1.0 (License.txt in the pack; copy at `assets_incoming/round2/ual_combat_extra/License_UAL1.txt`) | 0.90→f27 | break_heavy_kneel, crown_splitter, king_phase1 |
| `Hit_Chest` | Quaternius Universal Animation Library (Standard), file `Godot/AnimationLibrary_Godot_Standard.glb` | https://quaternius.itch.io/universal-animation-library · https://opengameart.org/content/universal-animation-library | CC0 1.0 (License.txt in the pack; copy at `assets_incoming/round2/ual_combat_extra/License_UAL1.txt`) | 0.12→f4, 0.20→f6 | stealth_backstab |
| `Hit_Head` | Quaternius Universal Animation Library (Standard), file `Godot/AnimationLibrary_Godot_Standard.glb` | https://quaternius.itch.io/universal-animation-library · https://opengameart.org/content/universal-animation-library | CC0 1.0 (License.txt in the pack; copy at `assets_incoming/round2/ual_combat_extra/License_UAL1.txt`) | 0.10→f3, 0.20→f6, 0.22→f7 | stealth_throat, turning_cut |
| `Hit_Knockback` | Quaternius Universal Animation Library 2 (Standard), file `Unreal-Godot/UAL2_Standard.glb` | https://quaternius.itch.io/universal-animation-library-2 · https://opengameart.org/content/universal-animation-library-2 | CC0 1.0 (License.txt in the pack; copy at `assets_incoming/round2/ual_combat_extra/License_UAL2.txt`) | 0.25→f8, 0.65→f20 | king_phase1 |
| `Hit_Stomach` | Quaternius Universal Animation Library 1 **Source/Pro** clip, single-clip GLB `quaternius-ual1-hit-stomach.glb` (VRM-style normalized humanoid skeleton, re-hosted by Drawcall Market) | https://market.drawcall.ai/asset/hit-stomach (zip: https://market.drawcallcontent.com/zips/…) · origin https://quaternius.com/packs/universalanimationlibrary.html | CC0 1.0, as stated on the Drawcall asset page ("Quaternius Universal Animation Library … Source CC0"); Quaternius releases the Source editions under CC0 too | 0.12→f4, 0.18→f5, 0.22→f7, 0.26→f8 | heart_pierce, king_phase1 |
| `Idle_Shield_Break` | Quaternius Universal Animation Library 2 (Standard), file `Unreal-Godot/UAL2_Standard.glb` | https://quaternius.itch.io/universal-animation-library-2 · https://opengameart.org/content/universal-animation-library-2 | CC0 1.0 (License.txt in the pack; copy at `assets_incoming/round2/ual_combat_extra/License_UAL2.txt`) | 0.30→f9, 0.32→f10, 0.34→f10, 0.60→f18 | break_heavy_kneel, break_heavy_stand, break_king_kneel, break_std, heart_pierce, king_phase1, shoulder_drive, turning_cut |
| `Kick` | Quaternius Universal Animation Library 1 **Source/Pro** clip, single-clip GLB `quaternius-ual1-kick.glb` (VRM-style normalized humanoid skeleton, re-hosted by Drawcall Market) | https://market.drawcall.ai/asset/kick-alternate-2 (zip: https://market.drawcallcontent.com/zips/…) · origin https://quaternius.com/packs/universalanimationlibrary.html | CC0 1.0, as stated on the Drawcall asset page ("Quaternius Universal Animation Library … Source CC0"); Quaternius releases the Source editions under CC0 too | 0.18→f5, 0.34→f10, 0.45→f14, 0.80→f24 | king_phase1 |
| `Sword_Dash_RM` | Quaternius Universal Animation Library 2 (Standard), file `Unreal-Godot/UAL2_Standard.glb` | https://quaternius.itch.io/universal-animation-library-2 · https://opengameart.org/content/universal-animation-library-2 | CC0 1.0 (License.txt in the pack; copy at `assets_incoming/round2/ual_combat_extra/License_UAL2.txt`) | 0.00→f0, 1.57→f47 | crown_splitter, heart_pierce, king_phase1, kingsfall, shoulder_drive, turning_cut |
| `Sword_Idle` | Quaternius Universal Animation Library (Standard), file `Godot/AnimationLibrary_Godot_Standard.glb` | https://quaternius.itch.io/universal-animation-library · https://opengameart.org/content/universal-animation-library | CC0 1.0 (License.txt in the pack; copy at `assets_incoming/round2/ual_combat_extra/License_UAL1.txt`) | 0.40→f12 | break_heavy_kneel, break_heavy_stand, break_king_kneel, break_std, stealth_backstab, stealth_throat |

**Authored poses**, not from a clip: `lunge, press, coil, pull_through, chiburi, shoulder_check, overhead, cleave, plunge_up, plunge_down, stab_back, hold_low, throat_hold, pass_cut, zanshin`. Their Euler values are in `work/db/build.py` and the tick tables are in the doc's Appendix A.
Pose aliases derived from clip frames: `brk_std` = Idle_Shield_Break@0.30, `brk_std_low` = Idle_Shield_Break@0.30, `brk_heavy_kneel` = Fixing_Kneeling@0.90, `brk_heavy_stand` = Idle_Shield_Break@0.60, `brk_heavy_sag` = Idle_Shield_Break@0.60, `kneel_both` = Death02@0.95, `unaware` = Sword_Idle@0.40, `stand_ready` = Sword_Dash_RM@1.57.

**Not reachable or not used:**
- **Mixamo:** needs an Adobe login. Candidate names are in the doc §12.
- **OpenGameArt "Humanoid SoulsLike Animations"** (Gres, CC0): `.blend` only, and there is no Blender in the sandbox.
- **CC0 Sketchfab sword finishers:** Sketchfab downloads need a login.
- **opengameasset.net "One Handed Sword Attacks and Finishers":** rejected. It re-hosts a commercial Unity pack, so its licence is not CC0.
- **No free CC0 sword *finisher* clip was found.** The strike poses are therefore authored from the direction doc and IK-pinned, as the brief allowed. The clip-body attempt is in `preview/rejected_clipbody_*.jpg`.

## Retime maps (core t → source)

### break_heavy_kneel
- **vic**: 0.00 Sword_Idle@0.4 · 0.12 Idle_Shield_Break@0.30 (out3) · 0.55 brk_heavy_kneel (in) · 0.80 brk_heavy_kneel (out) · 2.50 brk_heavy_kneel

### break_heavy_stand
- **vic**: 0.00 Sword_Idle@0.4 · 0.12 Idle_Shield_Break@0.30 (out3) · 0.60 brk_heavy_stand (out) · 2.50 brk_heavy_stand

### break_king_kneel
- **vic**: 0.00 Sword_Idle@0.4 · 0.12 Idle_Shield_Break@0.30 (out3) · 0.60 Death02@0.60 · 0.95 kneel_both (out) · 2.50 kneel_both

### break_std
- **vic**: 0.00 Sword_Idle@0.4 · 0.10 brk_std (out3) · 0.55 brk_std · 1.00 brk_std_low · 2.50 brk_std_low

### crown_splitter
- **att**: 0.00 Sword_Dash_RM@0.0 · 0.20 overhead (out) · 0.28 cleave (in) [blade→crown] · 0.32 cleave (out3) [blade→crownIn] · 0.80 cleave [blade→crownIn] · 1.20 cleave [blade→crownIn2] · 1.45 cleave [blade→crownIn2] · 1.65 overhead (out3) · 1.90 chiburi · 2.75 stand_ready
- **vic**: 0.00 brk_heavy_kneel · 0.24 brk_heavy_kneel · 0.32 brk_heavy_kneel (out3) · 0.80 brk_heavy_kneel · 1.45 brk_heavy_kneel · 1.65 Death01@0.90 (out) · 2.25 Death01@1.35 (in) · 3.00 Death01@2.4

### heart_pierce
- **att**: 0.00 Sword_Dash_RM@0.0 · 0.14 coil (out) · 0.28 lunge (in) [blade→heart] · 0.32 lunge (out3) [blade→heart] · 0.37 lunge (out) [blade→heart] · 0.43 lunge (out) [blade→heart] · 0.55 press (out) [blade→heart] · 0.75 press [blade→heart] · 0.95 press [blade→heart] · 1.15 pull_through (out3) · 1.40 chiburi (out) · 2.25 stand_ready
- **vic**: 0.00 brk_std_low · 0.24 Idle_Shield_Break@0.32 · 0.32 Idle_Shield_Break@0.34 (out3) · 0.42 Hit_Stomach@0.12 (out) · 0.55 Hit_Stomach@0.22 (out) · 0.95 Hit_Stomach@0.26 · 1.15 Death02@0.30 (out) · 1.65 Death02@0.90 · 2.60 Death02@2.0 (in)

### king_phase1
- **att**: 0.00 Sword_Dash_RM@0.0 · 0.14 coil (out) · 0.28 lunge (in) [blade→heart] · 0.32 lunge (out3) [blade→heart] · 0.37 lunge (out) [blade→heart] · 0.43 lunge (out) [blade→heart] · 0.80 press (out) [blade→heart] · 1.12 press [blade→heart] · 1.38 Kick@0.18 · 1.55 Kick@0.34 (out3) · 1.65 Kick@0.45 (out) · 1.90 Kick@0.80 · 2.75 stand_ready
- **vic**: 0.00 brk_std_low · 0.24 Idle_Shield_Break@0.32 · 0.32 Idle_Shield_Break@0.34 (out3) · 0.80 Hit_Stomach@0.18 · 1.20 Hit_Stomach@0.18 · 1.45 Hit_Stomach@0.18 · 1.65 Hit_Knockback@0.25 (out3) · 2.05 Hit_Knockback@0.65 (out) · 2.75 Fixing_Kneeling@0.9

### kingsfall
- **att**: 0.00 Sword_Dash_RM@0.0 · 0.20 plunge_up (out) [blade→heartTop] · 0.28 plunge_down (in) [blade→heartTop] · 0.32 plunge_down (out3) [blade→heartTop] · 0.80 plunge_down [blade→heartTop] · 1.15 plunge_down [blade→heartTop] · 1.45 plunge_down [blade→heartTop] · 1.65 overhead (out3) · 1.90 chiburi · 2.75 stand_ready
- **vic**: 0.00 kneel_both · 0.22 kneel_both · 0.32 kneel_both (out3) · 0.80 kneel_both · 1.15 kneel_both · 1.38 kneel_both · 1.45 kneel_both · 1.70 Death02@1.00 · 2.35 Death02@1.55 (in) · 3.00 Death02@2.4

### shoulder_drive
- **att**: 0.00 Sword_Dash_RM@0.0 · 0.14 coil (out) · 0.26 shoulder_check (in) [blade→clavL] · 0.32 shoulder_check (out3) [blade→clavL] · 0.55 shoulder_check [blade→clavL] · 0.95 shoulder_check [blade→clavL] · 1.15 overhead (out3) · 1.40 chiburi · 2.25 stand_ready
- **vic**: 0.00 brk_heavy_stand · 0.26 brk_heavy_stand · 0.32 brk_heavy_sag (out3) · 0.55 brk_heavy_sag (out) · 0.95 brk_heavy_sag · 1.15 Death01@0.25 (out) · 1.80 Death01@1.15 (in) · 2.70 Death01@2.4

### stealth_backstab
- **att**: 0.00 Crouch_Fwd_Loop@0.0 · 0.18 Crouch_Fwd_Loop@0.55 (lin) · 0.28 stab_back [blade→back] · 0.32 stab_back (out3) [blade→back] · 0.55 stab_back [blade→back] · 0.95 stab_back [blade→back] · 1.15 hold_low · 1.40 hold_low · 2.25 Crouch_Idle_Loop@0.0
- **vic**: 0.00 unaware · 0.26 unaware · 0.32 Hit_Chest@0.12 (out3) · 0.55 Hit_Chest@0.20 · 0.95 Hit_Chest@0.20 · 1.35 Death02@0.85 · 1.75 Death02@1.05 · 2.40 Death02@1.9 (in)

### stealth_throat
- **att**: 0.00 Crouch_Fwd_Loop@0.0 · 0.18 Crouch_Fwd_Loop@0.55 (lin) · 0.28 throat_hold [blade→throat] · 0.32 throat_hold (lin) [blade→throat] · 0.55 throat_hold (out) [blade→throat] · 0.95 throat_hold [blade→throat] · 1.15 hold_low · 1.40 hold_low · 2.25 Crouch_Idle_Loop@0.0
- **vic**: 0.00 unaware · 0.24 unaware · 0.30 unaware (out3) · 0.55 Hit_Head@0.20 (out) · 0.95 Hit_Head@0.20 · 1.35 Death02@0.85 · 1.80 Death02@1.1 · 2.40 Death02@1.9 (in)

### turning_cut
- **att**: 0.00 Sword_Dash_RM@0.0 · 0.16 coil (out) · 0.28 pass_cut (in) [blade→throat] · 0.32 pass_cut (lin) [blade→throat] · 0.40 pass_cut (lin) [blade→throat] · 0.55 zanshin (out3) · 0.95 zanshin · 1.15 chiburi (out) · 1.40 stand_ready · 2.25 stand_ready
- **vic**: 0.00 brk_std_low · 0.26 brk_std · 0.32 Hit_Head@0.10 (out3) · 0.55 Hit_Head@0.22 (out) · 0.95 Hit_Head@0.22 · 1.12 Hit_Head@0.22 · 1.35 Death02@0.35 (out) · 1.90 Death02@0.95 · 2.60 Death02@1.9 (in)

## Previews (`preview/`)
These were rendered with a lock-free software rasteriser (`work/db/soft.py`, painter's algorithm), using the game's pose-rig proportions on a box mannequin. The browser lock was held by the integration test runs for the whole session.
- `<variant>.jpg`: 8 core ticks × 2 views (side, 3/4). Wren is slate, the victim brown. The victim's own sword is hidden after Impact.
- `impact_all.jpg`: all 8 variants at Impact and at Settle, from each variant's C2 camera in the doc.
- `posture_breaks.jpg`: the 4 break clips.
- `source_probe_*.jpg`: the CC0 source clips as retargeted.
- `rejected_clipbody_*.jpg`: the first attempt, which used clip bodies for the strikes.
